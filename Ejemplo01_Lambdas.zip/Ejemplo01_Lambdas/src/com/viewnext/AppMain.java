package com.viewnext;

import com.viewnext.business.ItfzFuncional;

public class AppMain {

	public static void main(String[] args) {
		// Sintaxis: parametros -> cuerpo del metodo
		
		// Los nombres de los parametros no tienen porque llamarse igual
		// Al ser 2 parametros es ibligatorio usar los parentesis
		// No es obligatorio poner el tipo de los parametros
		// Si el cuerpo de la funcion es una sola linea tampoco es obligatorio las {}
		ItfzFuncional lambda1 = (n,e) -> "nombre: " + n + " edad: " + e;
		System.out.println(lambda1.infoPersonas("Pepito", 25));
		
		// Si pongo el tipo de dato a los parametros, todos o ninguno
		// Si pongo el tipo es obligatorio los parentesis
		ItfzFuncional lambda2 = (String n, int e) -> "nombre: " + n + " edad: " + e;
		System.out.println(lambda2.infoPersonas("Pepito", 25));
		
		// Si ponemos {} es obligatorio poner return
		ItfzFuncional lambda3 = (n,e) -> {
			return "nombre: " + n + " edad: " + e;
		};
		System.out.println(lambda3.infoPersonas("Pepito", 25));
		
		// es obligatorio poner {} cuando el cuerpo tiene mas de una linea
		ItfzFuncional lambda4 = (n,e) -> {
			e++;
			n = n.toUpperCase();
			return "nombre: " + n + " edad: " + e;
		};
		System.out.println(lambda4.infoPersonas("Pepito", 25));
		
		// Los lambdas soportan inferencia de tipos
		// var en todos los parametros o ninguno
		ItfzFuncional lambda5 = (var n, var e) -> "nombre: " + n + " edad: " + e;
		System.out.println(lambda5.infoPersonas("Pepito", 25));

	}

}
