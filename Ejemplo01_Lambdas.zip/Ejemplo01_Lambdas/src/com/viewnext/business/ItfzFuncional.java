package com.viewnext.business;

// Un interface funcional tiene un SOLO metodo abstracto

@FunctionalInterface
public interface ItfzFuncional {
	
	String infoPersonas(String nombre, int edad);

}
