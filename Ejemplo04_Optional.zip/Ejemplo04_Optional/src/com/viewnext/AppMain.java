package com.viewnext;

import java.util.Optional;

import com.viewnext.models.Producto;
import com.viewnext.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {

		ProductosDAO dao = new ProductosDAO();

		// Buscando un producto existente
		System.out.println(dao.buscarProducto(3)); // Optional<Producto>
		System.out.println(dao.buscarProducto(3).get()); // Producto

		// Buscando un producto que no existe
		System.out.println(dao.buscarProducto(3765576)); // Optional.empty
		// java.util.NoSuchElementException: No value present
		// System.out.println(dao.buscarProducto(3865567).get()); // Excepcion

		// Primera forma de evitar la excepcion
		System.out.println(dao.buscarProducto(3865567).orElse(new Producto()));

		// Segunda forma de evitar la excepcion
		Optional<Producto> opProducto = dao.buscarProducto(3865567);
		if (opProducto.isPresent()) {
			System.out.println(opProducto.get());
		} else {
			System.out.println("Ese producto no existe en nuestro catalogo");
		}

		// Tercera forma de evitar la excepcion
		opProducto = dao.buscarProducto(3865567);
		if (opProducto.isEmpty()) {
			System.out.println("Ese producto no existe en nuestro catalogo");
		} else {
			System.out.println(opProducto.get());
		}

	}

}
