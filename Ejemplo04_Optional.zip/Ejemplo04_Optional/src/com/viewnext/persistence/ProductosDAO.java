package com.viewnext.persistence;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.viewnext.models.Producto;

public class ProductosDAO {
	
	private List<Producto> lista = Arrays.asList(
			new Producto(1, "Pantalla", 129.95),
			new Producto(2, "Teclado", 37.5),
			new Producto(3, "Raton", 18.75),
			new Producto(4, "Impresora", 89.90),
			new Producto(5, "Scanner", 300)
			);
	
	public Optional<Producto> buscarProducto(int id){
		// Version 1
		for (Producto producto : lista) {
			if (id == producto.getId()) {
				// Crear un optional con ese producto y retornarlo
				return Optional.of(producto);
			}
		}
		
		// Si no lo encuentro devuelvo un optional vacio
		return Optional.empty();
		
		
		// Version 2
//		return lista.stream()
//				.filter(p -> id == p.getId())
//				.findFirst();
	}

}
