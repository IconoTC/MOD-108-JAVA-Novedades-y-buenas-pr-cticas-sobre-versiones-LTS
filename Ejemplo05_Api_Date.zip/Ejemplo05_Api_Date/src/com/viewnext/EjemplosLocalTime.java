package com.viewnext;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class EjemplosLocalTime {

	public static void main(String[] args) {
		
		// Hora actual
		LocalTime ahora = LocalTime.now();
		System.out.println(ahora);
		
		// Solo horas:minutos
		System.out.println(ahora.truncatedTo(ChronoUnit.MINUTES));
		//  java.time.temporal.UnsupportedTemporalTypeException: Unit is too large to be used for truncation
		//System.out.println(ahora.truncatedTo(ChronoUnit.YEARS));
		
		// Hora fin de clase
		LocalTime fin = LocalTime.of(20, 0);
		
		// Cuanto nos queda de clase
		System.out.println("Nos quedan " + ahora.until(fin, ChronoUnit.HOURS)  + " horas");
		System.out.println("Nos quedan " + ahora.until(fin, ChronoUnit.MINUTES)  + " minutos");
		
		System.out.println(ahora.toSecondOfDay() + " segundos");
		System.out.println(ahora.toSecondOfDay() / 60 + " minutos");
		System.out.println(ahora.toSecondOfDay() / 60 / 60 + " horas");
	}

}
