package com.viewnext;

import com.viewnext.business.ItfzMetodos;

public class AppMain {

	public static void main(String[] args) {
		
		// Invocar al metodo estatico de la interface
		ItfzMetodos.estatico();
		
		// Invocar al metodo default de la interface
		ItfzMetodos impl = new ItfzMetodos() {
		};
		impl.defecto();

		System.out.println(impl.procesarTexto("Hola, que tal?"));
	}

}
