var numero1 = 6;
var numero2 = 5;
print("Suma: " + (numero1 + numero2))