package com.viewnext;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class AppMain {

	public static void main(String[] args) throws ScriptException {
		
		/*
		 * IMPORTANTE!! el proyecto debe estar configurado con Java 8
		 */
		
		// Obtener una instancia del motor JS
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine nashorn = manager.getEngineByName("nashorn");
		
		// Ejecutar codigo JS
		nashorn.eval("print('Hola')");
		
		// Ejecutar codigo.js
		nashorn.eval("load('codigo.js')");

	}

}
