package com.viewnext;

import java.util.concurrent.CompletableFuture;

public class Ejemplo3_Encadenar {

	public static void main(String[] args) {
		
		CompletableFuture.supplyAsync(() -> "Hola, ")
			.thenApply(resultado -> resultado + "que tal?")
			.thenAcceptAsync(System.out::println)
			.join();
		

	}

}
