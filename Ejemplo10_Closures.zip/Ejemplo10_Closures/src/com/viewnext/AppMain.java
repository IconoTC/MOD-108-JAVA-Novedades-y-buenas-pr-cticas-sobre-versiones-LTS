package com.viewnext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.viewnext.models.Producto;

public class AppMain {
	
	public static List<Producto> filtrarProductos(List<Producto> lista, Predicate<Producto> filtro){
		// Opcion tradicional
		List<Producto> listaNueva = new ArrayList<>();
		for (Producto producto : lista) {
			if (filtro.test(producto)) {
				listaNueva.add(producto);
			}
		}
		//return listaNueva;
		
		
		// Opcion con Java 8
		return lista.stream()
				.filter(filtro)
				.collect(Collectors.toList());
	}

	public static void main(String[] args) {
		List<Producto> lista = Arrays.asList(
				new Producto(1, "Pantalla", 129.95),
				new Producto(2, "Teclado", 37.5),
				new Producto(3, "Raton", 18.75),
				new Producto(4, "Impresora", 89.90),
				new Producto(5, "Scanner", 300)
				);
		
		// 1ª forma: instanciar Predicate
		filtrarProductos(lista, new Predicate<Producto>() {
			
			@Override
			public boolean test(Producto prod) {
				// Precio superior a 100
				return prod.getPrecio() > 100;
			}
		}).forEach(System.out::println);
		System.out.println("---------------------------");
		
		// 2ª forma: utilizar lambdas
		filtrarProductos(lista, prod -> prod.getPrecio() > 100)
			.forEach(System.out::println);
		System.out.println("---------------------------");
		
		
		// Filtrar por descripcion que tenga mas de 6 caracteres
		filtrarProductos(lista, prod -> prod.getDescripcion().length() > 6)
			.forEach(System.out::println);
		System.out.println("---------------------------");
		
		
		// Filtrar por los productos cuya descripcion comienza por P (startWith, charAt)
		filtrarProductos(lista, prod -> prod.getDescripcion().startsWith("P"))
			.forEach(System.out::println);
		System.out.println("---------------------------");
		
		filtrarProductos(lista, prod -> prod.getDescripcion().charAt(0) == 'P')
			.forEach(System.out::println);
		System.out.println("---------------------------");
		
		
		
		
		
		

	}

}
