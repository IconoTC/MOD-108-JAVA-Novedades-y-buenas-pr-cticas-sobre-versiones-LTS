module Ejemplo12_HTTP_Usuarios {
	
	requires java.net.http;
	requires org.json;
}
