package com.viewnext;

import java.util.Optional;

public class Ejemplo_OrElseThrow {

	public static void main(String[] args) {
		
		Optional<String> op = Optional.ofNullable(null);
		//Optional<String> op = Optional.ofNullable("Hola");
		
		// Si el optional esta vacio lanzamos una excepcion
		// Si no lo esta, mostraremos el valor
		// java.util.NoSuchElementException: No value present
		//String valor = op.orElseThrow();
		//System.out.println(valor);
		
		// Lanzar una excepcion personalizada (elijo el tipo y mensaje)
		String valor = op.orElseThrow(() -> new RuntimeException("El valor es nulo"));
		System.out.println(valor);

	}

}
