package com.viewnext;

import java.util.Arrays;
import java.util.Optional;

public class Ejemplo_Stream {

	public static void main(String[] args) {
		
		Optional<String> op = Optional.of("      Hola Juan como estas?      ");
		
		// Primero quitar los espacios derecha e izquierda
		// Partir el texto por " "
		// Mostrar en consola
		op.stream()
			.map(texto -> texto.strip())
			.map(texto -> Arrays.stream(texto.split(" ")))
			.forEach(x -> x.forEach(System.out::println));

	}

}
