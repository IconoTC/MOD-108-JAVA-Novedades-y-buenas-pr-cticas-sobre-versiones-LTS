package com.viewnext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class AppMain {
	
	// No funciona con variables globales o propiedades
	// Solo funciona con variables locales
	//var a = 125;

	public static void main(String[] args) {
		
		// Una vez que la variable ha inferido el tipo no se puede cambiar
		var dato = 64;
		//dato = "Hola";
		//dato = false;
		
		// Es obligatorio pasar un valor a la variable
		//var a;
		//var b = null;
		
		// Tampoco funciona con declaraciones multiples
		//var a, b = 7;
		//var c = 6, d = 2;
		
		// En arrays funciona dependiendo de como se declaren
		// var letras[] = {'a','e','i','o','u'};   NO funciona
		var letras = new char[]{'a','e','i','o','u'}; 
		
		// En colecciones tambien funciona
		var lista = new ArrayList<>();   // Lista de objetos
		var lista2 = new ArrayList<String>(); // Lista de cadenas de texto
		var lista3 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5)); // Lista de numeros enteros
		var lista4 = new ArrayList<>(Arrays.asList(1,2,3,4,5));  // Lista de numeros enteros
		
		var set = new HashSet<>();  // Conjunto de objetos
		var set2 = new HashSet<String>();   // Conjunto de cadenas de texto
		var set3 = new HashSet<String>(Arrays.asList("Juan", "Maria", "Pedro", "Laura"));
		var set4 = new HashSet<>(Arrays.asList("Juan", "Maria", "Pedro", "Laura"));
		
		var mapa = new HashMap<>();  // Mapa donde clave y valor son de tipo Object
		var mapa2 = new HashMap<String, Double>();  // Map<String, Double>
		var mapa3 = Map.of("a", 1.0, "b", 2.5); // Map<String, Double>
		var mapa4 = Map.ofEntries(Map.entry("a", 1.0), Map.entry("b", 2.5));  // Map<String, Double>
		
		// El uso de inferencia de tipos en bucles tambien funciona
		for(var num = 1; num <= 10; num++) {
			System.out.println(num);
		}
		
		for(var nombre : set3) {
			System.out.println(nombre);
		}

	}

}
