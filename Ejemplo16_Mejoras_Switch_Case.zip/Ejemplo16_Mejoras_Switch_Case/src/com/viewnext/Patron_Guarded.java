package com.viewnext;

public class Patron_Guarded {

	public static void main(String[] args) {
		
		//Object dato = "pepito@gmail.com";
		//Object dato = "pepitogmail.com";
		Object dato = "pep";
		//Object dato = 1234;
		
		// Solo funciona a partir de Java 21
		String mensaje = switch (dato) {
			case String email -> {
				if (email.length() < 5) 
					yield "Email no tiene sufientes caracteres";
				else if ( ! email.contains("@"))
					yield "Formato del email no es valido";
				else if ( ! email.contains("."))
					yield "Formato del email no es valido";
				else
					yield "Email valido";
			}
			default -> "Email no es valido";
		};
		
		System.out.println(mensaje);

	}

}
