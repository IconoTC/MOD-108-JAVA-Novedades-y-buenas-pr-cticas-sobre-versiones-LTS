package com.viewnext;

public class Patron_Parenthesized {

	public static void main(String[] args) {
		
		Object dato = "pepito@gmail.com";
		//Object dato = "pepitogmail.com";
		//Object dato = "pep";
		//Object dato = 1234;
		
		// Solo funciona a partir de Java 21
		String mensaje = switch (dato) {
			case String email  when (email.length() > 5 && email.contains("@") && email.contains("."))  -> "Email valido";
			default -> "Email no es valido";
		};
		
		System.out.println(mensaje);

	}

}
