package com.viewnext;

public class Patron_Type {

	public static void main(String[] args) {
		
		// No funciona con inferencia de tipos
		//Object dato = 456654366L;
		//Object dato = 45665.4366;
		//Object dato = "Hola";
		Object dato = 45665;
		
		// Patron Type
		String formato = switch (dato) {
			case String texto -> texto;
			case Integer entero -> String.format("entero %d ", entero);
			case Double real -> String.format("double %.1f ", real);
			case Long numLong -> String.format("long %d ", numLong);
			
			default -> dato.toString();
		};

		System.out.println(formato);
	}

}
