package com.viewnext;

import com.viewnext.models.Circulo;
import com.viewnext.models.Figura;
import com.viewnext.models.Rectangulo;

public class AppMain {

	public static void main(String[] args) {
		
		Figura circulo = new Circulo(56);
		System.out.println("Area del circulo: " + circulo.calcularArea());
		
		Figura rectangulo = new Rectangulo(40, 25);
		System.out.println("Area del rectangulo: " + rectangulo.calcularArea());

	}

}
