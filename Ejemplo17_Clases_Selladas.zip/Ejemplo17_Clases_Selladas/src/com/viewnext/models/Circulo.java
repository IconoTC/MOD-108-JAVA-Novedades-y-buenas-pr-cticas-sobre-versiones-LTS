package com.viewnext.models;

// Ahora la clase Circulo debe declararse de una de estas formas:
//		1.- final -> Ya no se puede heredar de ella
//		2.- non-sealed -> Hemos quitado el sellado, cualquier otra clase puede heredar de Circulo
//		3.- sealed -> Sigue siendo una clase sellada, y tendremos que indicar que subclases tienen
//						permiso para heredar de ella
public sealed class Circulo extends Figura permits Elipse{

	private double radio;

	public Circulo() {
		// TODO Auto-generated constructor stub
	}

	public Circulo(double radio) {
		super();
		this.radio = radio;
	}

	@Override
	public double calcularArea() {
		return Math.PI * Math.pow(radio, 2);
	}

	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}

	@Override
	public String toString() {
		return "Circulo [radio=" + radio + "]";
	}
	
}
