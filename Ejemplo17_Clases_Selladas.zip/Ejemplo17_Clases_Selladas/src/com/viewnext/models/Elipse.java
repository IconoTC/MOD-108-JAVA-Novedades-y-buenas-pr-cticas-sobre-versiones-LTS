package com.viewnext.models;

// ERROR porque Circulo esta declarada como Final
// Si la clase Circulo se declara como non-sealed Funciona
// Si la clase Circulo se declara como sealed y tenemos permiso para heredar
// Necistamos poner final, non-sealed o sealed
public final class Elipse extends Circulo{

}
