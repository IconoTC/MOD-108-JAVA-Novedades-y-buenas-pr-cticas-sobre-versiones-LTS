package com.viewnext.models;

// Una clase sellada controla que subclase tiene permiso para heredar de ella
// En nuestro ejemplo, solo Circulo puede heredar de Figura
// Añadimos tambien Rectangulo con permisos
public abstract sealed class Figura permits Circulo, Rectangulo{
	
	public abstract double calcularArea();

}
