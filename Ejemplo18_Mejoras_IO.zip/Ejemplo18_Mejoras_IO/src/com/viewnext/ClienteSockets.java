package com.viewnext;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClienteSockets {

	public static void main(String[] args) throws UnknownHostException, IOException {
		
		String host = "localhost";
		int puerto = 32915;
		
//		Socket socket = new Socket(host, puerto);
//		
//		// Enviar mensaje
//		ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
//		oos.writeObject("Hola, esto es una prueba de sockets");
//		
//		// Cerrar recursos
//		oos.close();
//		socket.close();
		
		try (Socket socket = new Socket(host, puerto);
				ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());) {
			
			oos.writeObject("Hola, esto es una prueba de sockets");
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
