package com.viewnext;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.zip.GZIPOutputStream;

public class ComprimirFichero {

	public static void main(String[] args) {
		
		try (FileOutputStream fichero = new FileOutputStream("comprimido.zip");
				GZIPOutputStream gStream = new GZIPOutputStream(fichero);
				BufferedWriter bWriter = new BufferedWriter(new OutputStreamWriter(gStream))){
			
			bWriter.write("Esto es una prueba para ver la compresion de ficheros");
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
