package com.viewnext;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorSockets {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		int puerto = 32915;
//		ServerSocket servidor = new ServerSocket(puerto);
//		
//		while (true) {
//			Socket socket = servidor.accept();
//			ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
//			String mensaje = (String) ois.readObject();
//			System.out.println("Mensaje recibido: " + mensaje);
//			
//			// Cerrar recursos
//			ois.close();
//			socket.close();
//		}
		
		try (ServerSocket servidor = new ServerSocket(puerto)) {
			
			while(true) {
				try (Socket socket = servidor.accept();
					 ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());){
					
					String mensaje = (String) ois.readObject();
					System.out.println("Mensaje recibido: " + mensaje);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
