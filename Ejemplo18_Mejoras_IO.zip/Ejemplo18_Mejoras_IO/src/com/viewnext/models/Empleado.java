package com.viewnext.models;

import java.io.Serializable;

// Para poder serializar instancias de Empleado
// la clase debe implementar la interfaz Serializable
// Serializable es una interface de marca, no hay ningun metodo abstracto que implementar
public class Empleado implements Serializable{
	
	private int numEmpleado;
	private String nombre;
	private double sueldo;
	
	public Empleado() {
		// TODO Auto-generated constructor stub
	}

	public Empleado(int numEmpleado, String nombre, double sueldo) {
		super();
		this.numEmpleado = numEmpleado;
		this.nombre = nombre;
		this.sueldo = sueldo;
	}

	public int getNumEmpleado() {
		return numEmpleado;
	}

	public void setNumEmpleado(int numEmpleado) {
		this.numEmpleado = numEmpleado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		return "Empleado [numEmpleado=" + numEmpleado + ", nombre=" + nombre + ", sueldo=" + sueldo + "]";
	}
	
}
