module Ejemplo20_Crear_Modulo {
	
	// exports paquete
	exports com.viewnext.models;
}