module Ejercicio01_HTTP_Pokemons {
	
	requires java.net.http;
	requires org.json;
}